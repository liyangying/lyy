package com.controller;

import com.pojo.Content;
import com.service.ContentService;
import com.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;



@Controller
@RequestMapping("/content")
public class ContentController {

    @Autowired
    private ContentService contentService;

    //显示所有内容
    @RequestMapping("/allContent")
    public String list(Model model) {
        List<Content> list = contentService.queryAllContent();
        model.addAttribute("list", list);
        return "allContent";
    }

    //新增内容
    @RequestMapping("toAddContent")
    public String toAddContent() {
        return "addContent";
    }

    @RequestMapping("/addContent")
    public String addContent(Content content) {
        contentService.addContent(content);
        return "redirect:/content/allContent";
    }

    //删除内容
    @RequestMapping("/del/{contentId}")
    public String deleteContent(@PathVariable("contentId") Long id) {
        contentService.deleteContentById(id);
        return "redirect:/content/allContent";
    }

    //更新内容
    @RequestMapping("toUpdateContent")
    public String toUpdateContent(Model model, Long id) {
        System.out.println(contentService.queryById(id).toString());
        model.addAttribute("content", contentService.queryById(id));
        return "updateContent";
    }

    @RequestMapping("/updateContent")
    public String updateContent(Model model, Content content) {
        contentService.updateContent(content);
        content = contentService.queryById(content.getContentId());
        model.addAttribute("content", content);
        return "redirect:/content/allContent";
    }



    /**
     * 处理图片显示请求
     * @param fileName
     */
    @RequestMapping("/showPic/{fileName}.{suffix}")
    public void showPicture(@PathVariable("fileName") String fileName,
                            @PathVariable("suffix") String suffix,
                            HttpServletResponse response){
        File imgFile = new File(Constants.IMG_PATH + fileName + "." + suffix);
        responseFile(response, imgFile);
    }

    /**
     * 处理图片下载请求
     * @param fileName
     * @param response
     */
    @RequestMapping("/downloadPic/{fileName}.{suffix}")
    public void downloadPicture(@PathVariable("fileName") String fileName,
                                @PathVariable("suffix") String suffix,
                                HttpServletResponse response){
        // 设置下载的响应头信息
        response.setHeader("Content-Disposition",
                "attachment;fileName=" + "headPic.jpg");
        File imgFile = new File(Constants.IMG_PATH + fileName + "." + suffix);
        responseFile(response, imgFile);
    }

    /**
     * 响应输出图片文件
     * @param response
     * @param imgFile
     */
    private void responseFile(HttpServletResponse response, File imgFile) {
        try(InputStream is = new FileInputStream(imgFile);
            OutputStream os = response.getOutputStream();){
            byte [] buffer = new byte[1024]; // 图片文件流缓存池
            while(is.read(buffer) != -1){
                os.write(buffer);
            }
            os.flush();
        } catch (IOException ioe){
            ioe.printStackTrace();
        }
    }
}
